#include "formtransaksi.h"
#include "ui_formtransaksi.h"

FormTransaksi::FormTransaksi(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::FormTransaksi)
{
    ui->setupUi(this);
}

FormTransaksi::~FormTransaksi()
{
    delete ui;
}

void FormTransaksi::on_pushButton_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("INSERT INTO transaksi (id_transaksi,id_barang,id_pemberi,tanggal,keterangan)"
                "VALUE(:id_transaksi,:id_barang,:id_pemberi,:tanggal,:keterangan)");
    sql.bindValue(":id_transaksi",ui->iDTransaksiLineEdit->text());
    sql.bindValue(":id_barang",ui->iDBarangLineEdit->text());
    sql.bindValue(":id_pemberi",ui->iDPemberiLineEdit->text());
    sql.bindValue(":tanggal",ui->tanggalDateEdit->date());
    sql.bindValue(":keterangan",ui->keteranganLineEdit->text());


    if (sql.exec()){
        qDebug()<<"Data Berhasil Disimpan";
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormTransaksi::on_pushButton_2_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("UPDATE transaksi SET id_barang=:id_barang, id_pemberi=:id_pemberi, tanggal=:tanggal,"
                "keterangan=:keterangan where id_transaksi=:id_transaksi");
    sql.bindValue(":id_transaksi",ui->iDTransaksiLineEdit->text());
    sql.bindValue(":id_barang",ui->iDBarangLineEdit->text());
    sql.bindValue(":id_pemberi",ui->iDPemberiLineEdit->text());
    sql.bindValue(":tanggal",ui->tanggalDateEdit->date());
    sql.bindValue(":keterangan",ui->keteranganLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di ubah";
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormTransaksi::on_pushButton_3_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("DELETE FROM transaksi WHERE id_transaksi=:id_transaksi");
    sql.bindValue(":id_transaksi",ui->iDTransaksiLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di Hapus";
    }else{
        qDebug()<<sql.lastError().text();
    }
}

