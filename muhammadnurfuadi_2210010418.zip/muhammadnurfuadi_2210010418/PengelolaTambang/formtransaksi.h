#ifndef FORMTRANSAKSI_H
#define FORMTRANSAKSI_H

#include <QWidget>
#include <QtSql>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QDebug>

namespace Ui {
class FormTransaksi;
}

class FormTransaksi : public QWidget
{
    Q_OBJECT

public:
    explicit FormTransaksi(QWidget *parent = nullptr);
    ~FormTransaksi();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::FormTransaksi *ui;
    QSqlDatabase koneksi;
    QSqlQuery sql;
};

#endif // FORMTRANSAKSI_H
