#ifndef FORMPEMBELI_H
#define FORMPEMBELI_H

#include <QWidget>
#include <QtSql>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QDebug>

namespace Ui {
class FormPembeli;
}

class FormPembeli : public QWidget
{
    Q_OBJECT

public:
    explicit FormPembeli(QWidget *parent = nullptr);
    ~FormPembeli();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::FormPembeli *ui;
    QSqlDatabase koneksi;
    QSqlQuery sql;
};

#endif // FORMPEMBELI_H
