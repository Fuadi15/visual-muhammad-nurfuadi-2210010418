#include "formpembayaran.h"
#include "ui_formpembayaran.h"

FormPembayaran::FormPembayaran(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::FormPembayaran)
{
    ui->setupUi(this);
}

FormPembayaran::~FormPembayaran()
{
    delete ui;
}

void FormPembayaran::on_pushButton_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("INSERT INTO pembayaran (id_pembayaran,total_bayar,tgl_bayar,id_transaksi)"
                "VALUE(:id_pembayaran,:total_bayar,:tgl_bayar,:id_transaksi)");
    sql.bindValue(":id_pembayaran",ui->iDPembayaranLineEdit->text());
    sql.bindValue(":total_bayar",ui->totalBayarLineEdit->text());
    sql.bindValue(":tgl_bayar",ui->tanggalBayarDateEdit->date());
    sql.bindValue(":id_transaksi",ui->iDTransaksiLineEdit->text());


    if (sql.exec()){
        qDebug()<<"Data Berhasil Disimpan";
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormPembayaran::on_pushButton_2_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("UPDATE pembayaran SET total_bayar=:total_bayar, tgl_bayar=:tgl_bayar,"
                "id_transaksi=:id_transaksi where id_pembayaran=:id_pembayaran");
    sql.bindValue(":id_pembayaran",ui->iDPembayaranLineEdit->text());
    sql.bindValue(":total_bayar",ui->totalBayarLineEdit->text());
    sql.bindValue(":tgl_bayar",ui->tanggalBayarDateEdit->date());
    sql.bindValue(":id_transaksi",ui->iDTransaksiLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di ubah";
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormPembayaran::on_pushButton_3_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("DELETE FROM pembayaran WHERE id_pembayaran=:id_pembayaran");
    sql.bindValue(":id_pembayaran",ui->iDPembayaranLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di Hapus";
    }else{
        qDebug()<<sql.lastError().text();
    }
}

