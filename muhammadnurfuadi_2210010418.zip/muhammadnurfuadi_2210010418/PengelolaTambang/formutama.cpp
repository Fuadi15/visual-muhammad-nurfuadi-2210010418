#include "formutama.h"
#include "ui_formutama.h"

FormUtama::FormUtama(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::FormUtama)
{
    ui->setupUi(this);
    barang = new FormBarang;
    pembayaran = new FormPembayaran;
    pembeli = new FormPembeli;
    transaksi = new FormTransaksi;
    supplier = new FormSupplier;
}

FormUtama::~FormUtama()
{
    delete ui;
}

void FormUtama::on_pushButton_clicked()
{
    barang->show();
}


void FormUtama::on_pushButton_2_clicked()
{
    pembayaran->show();
}


void FormUtama::on_pushButton_3_clicked()
{
    pembeli->show();
}


void FormUtama::on_pushButton_5_clicked()
{
    transaksi->show();
}


void FormUtama::on_pushButton_4_clicked()
{
    supplier->show();
}

