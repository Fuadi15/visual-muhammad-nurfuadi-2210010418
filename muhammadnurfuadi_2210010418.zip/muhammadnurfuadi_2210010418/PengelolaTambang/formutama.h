#ifndef FORMUTAMA_H
#define FORMUTAMA_H

#include <QMainWindow>
#include <formbarang.h>
#include <formpembayaran.h>
#include <formpembeli.h>
#include <formtransaksi.h>
#include <formsupplier.h>

QT_BEGIN_NAMESPACE
namespace Ui {
class FormUtama;
}
QT_END_NAMESPACE

class FormUtama : public QMainWindow
{
    Q_OBJECT

public:
    FormUtama(QWidget *parent = nullptr);
    ~FormUtama();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::FormUtama *ui;
    FormBarang *barang;
    FormPembayaran *pembayaran;
    FormPembeli *pembeli;
    FormTransaksi *transaksi;
    FormSupplier *supplier;
};
#endif // FORMUTAMA_H
