#include "formpembeli.h"
#include "ui_formpembeli.h"

FormPembeli::FormPembeli(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::FormPembeli)
{
    ui->setupUi(this);
}

FormPembeli::~FormPembeli()
{
    delete ui;
}

void FormPembeli::on_pushButton_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("INSERT INTO pembeli (id_pembeli,nama_pembeli,jk,no_telp,alamat)"
                "VALUE(:id_pembeli,:nama_pembeli,:jk,:no_telp,:alamat)");
    sql.bindValue(":id_pembeli",ui->iDPembeliLineEdit->text());
    sql.bindValue(":nama_pembeli",ui->namaPembeliLineEdit->text());
    sql.bindValue(":jk",ui->jenisKelaminComboBox->currentText());
    sql.bindValue(":no_telp",ui->TelpLineEdit->text());
    sql.bindValue(":alamat",ui->alamatLineEdit->text());


    if (sql.exec()){
        qDebug()<<"Data Berhasil Disimpan";
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormPembeli::on_pushButton_2_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("UPDATE pembeli SET nama_pembeli=:nama_pembeli, jk=:jk, no_telp=:no_telp, "
                "alamat=:alamat where id_pembeli=:id_pembeli");
    sql.bindValue(":id_pembeli",ui->iDPembeliLineEdit->text());
    sql.bindValue(":nama_pembeli",ui->namaPembeliLineEdit->text());
    sql.bindValue(":jk",ui->jenisKelaminComboBox->currentText());
    sql.bindValue(":no_telp",ui->TelpLineEdit->text());
    sql.bindValue(":alamat",ui->alamatLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di ubah";
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormPembeli::on_pushButton_3_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("DELETE FROM pembeli WHERE id_pembeli=:id_pembeli");
    sql.bindValue(":id_pembeli",ui->iDPembeliLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di Hapus";
    }else{
        qDebug()<<sql.lastError().text();
    }
}

