#include "formsupplier.h"
#include "ui_formsupplier.h"

FormSupplier::FormSupplier(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::FormSupplier)
{
    ui->setupUi(this);
}

FormSupplier::~FormSupplier()
{
    delete ui;
}

void FormSupplier::on_pushButton_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("INSERT INTO supplier (id_supplier,nama_supplier,no_telp,alamat)"
                "VALUE(:id_supplier,:nama_supplier,:no_telp,:alamat)");
    sql.bindValue(":id_supplier",ui->iDSupplierLineEdit->text());
    sql.bindValue(":nama_supplier",ui->namaSupplierLineEdit->text());
    sql.bindValue(":no_telp",ui->telpLineEdit->text());
    sql.bindValue(":alamat",ui->alamatLineEdit->text());


    if (sql.exec()){
        qDebug()<<"Data Berhasil Disimpan";
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormSupplier::on_pushButton_2_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("UPDATE supplier SET nama_supplier=:nama_supplier, no_telp=:no_telp, "
                "alamat=:alamat where id_supplier=:id_supplier");
    sql.bindValue(":id_supplier",ui->iDSupplierLineEdit->text());
    sql.bindValue(":nama_supplier",ui->namaSupplierLineEdit->text());
    sql.bindValue(":no_telp",ui->telpLineEdit->text());
    sql.bindValue(":alamat",ui->alamatLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di ubah";
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormSupplier::on_pushButton_3_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("DELETE FROM supplier WHERE id_supplier=:id_supplier");
    sql.bindValue(":id_supplier",ui->iDSupplierLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di Hapus";
    }else{
        qDebug()<<sql.lastError().text();
    }
}

